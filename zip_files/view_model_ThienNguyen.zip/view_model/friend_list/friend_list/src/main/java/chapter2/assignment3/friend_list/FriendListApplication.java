package chapter2.assignment3.friend_list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendListApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendListApplication.class, args);
	}

}
