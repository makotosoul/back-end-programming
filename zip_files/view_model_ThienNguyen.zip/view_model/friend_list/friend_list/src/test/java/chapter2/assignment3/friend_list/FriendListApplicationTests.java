package chapter2.assignment3.friend_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendListApplicationTests {

	@Test
	void contextLoads() {
	}

}
