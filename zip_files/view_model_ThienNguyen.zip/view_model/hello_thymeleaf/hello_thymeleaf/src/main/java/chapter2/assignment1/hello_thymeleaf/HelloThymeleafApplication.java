package chapter2.assignment1.hello_thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloThymeleafApplication.class, args);
	}

}
