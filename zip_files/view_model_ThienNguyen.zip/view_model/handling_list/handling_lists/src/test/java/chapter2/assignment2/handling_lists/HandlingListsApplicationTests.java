package chapter2.assignment2.handling_lists;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandlingListsApplicationTests {

	@Test
	void contextLoads() {
	}

}
