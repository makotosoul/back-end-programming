package chapter2.assignment2.handling_lists;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandlingListsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandlingListsApplication.class, args);
	}

}
